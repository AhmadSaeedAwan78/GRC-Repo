@extends(($user_type=='admin')?('admin.layouts.admin_app'):('admin.client.client_app'))
@section('content')
@if (Auth::user()->role == 1)
<div class="app-title">
	<ul class="app-breadcrumb breadcrumb">
		<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i>
		</li>
		<li class="breadcrumb-item"><a href="{{URL::current()}}">{{$heading}}</a>
		</li>
	</ul>
</div>
@endif
@if (session('alert'))
    <div class="alert alert-primary">
        {{ session('alert') }}
    </div>
@endif

<div class="row" style="padding-left:20px; padding-right:12px;">
	<div class="col-md-12">
		<div class="tile">
			<h3 class="tile-title">{{ $heading }}</h3>
			<div class="table-responsive">
				<table class="table" id="report_table">
					<thead class="back_blue">
						<tr>
							<th>Question</th>
							<th>Options</th>
							<th>Additional Comment</th>
							<th>Response</th>
							<th>Form</th>
							<th>User</th>
							<th>Organization</th>
							<th>Date</th>
						</tr>
					</thead>
					<tbody>
						@foreach($response_reports as $resp_info)
						<tr>
							<td>{{$resp_info->question}}</td>
							<td>{{$resp_info->options}}</td>
							<td>{{$resp_info->additional_comment}}</td>
							<td>
							    @php
							        if ($resp_info->custom_case)
							        {
							            $response = json_decode($resp_info->question_response, true);
							            if (gettype($response) == 'array')
							            {
    							           foreach ($response as $key => $value)
    							           {
							                    if (gettype($value) == 'array')
							                    {
							                        foreach ($value as $k => $v)
							                        {
							                        	echo $v."<br>";
							                        }
							                    }
							                    else
							                    {
							                        echo $value."<br>";
							                    }
    							           }							            
							            }
							            //print_r($response);
							        }
							        else
							        {
							            echo $resp_info->question_response;
							        }
							        
							    @endphp
							</td>							
							<td>{{$resp_info->title}}</td>
							<td>{{isset($resp_info->user_email)?($resp_info->user_email):($resp_info->client_email) }}</td>
							<td>{{$resp_info->name}}</td>
							<td>{{$resp_info->time}}</td>
						</tr>
						@endforeach
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<script>
$(document).ready(function() {
	
    // Setup - add a text input to each footer cell
    $('#report_table thead tr').clone(true).appendTo('#report_table thead');	
    $('#report_table thead tr:eq(1) th').each(function (i) {
        var title = $(this).text();
        $(this).html('<input type="text" placeholder="Search '+title+'" />');
 
        $('input', this ).on('keyup change', function () {
            if (table.column(i).search() !== this.value) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        });
		
    });
	
	var table = $('#report_table').DataTable({
        orderCellsTop: true,
        //fixedHeader: true
    });	
 
	//$('#report_table').DataTable();

});
</script>
@endsection