@extends('users.ex_user_app')
@section('content')
<div style="margin-left:30px">
  {{ $msg }}
</div>
<script>

</script>
@endsection